-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Jan 2022 pada 00.54
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bukuperpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `judulBuku` text DEFAULT NULL,
  `totalBuku` int(11) DEFAULT NULL,
  `tahun` int(11) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `idUsers` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id`, `judulBuku`, `totalBuku`, `tahun`, `createDate`, `idUsers`) VALUES
(7, 'Laskar Pelangi', 2, 10000, '2021-12-22 10:54:21', 8),
(19, 'Dasar Flutter', 29, 2002, '2021-12-22 15:06:38', 4),
(20, 'Aljabar Linear', 50, 2020, '2021-12-31 10:23:41', 9);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `nama` text DEFAULT NULL,
  `createDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `nama`, `createDate`) VALUES
(2, 'rng@gmail.com', 'c3ec0f7b054e729c5a716c8125839829', 'rng', '2021-12-20 13:46:30'),
(3, 'saputra@gmail.com', 'c3ec0f7b054e729c5a716c8125839829', 'saputra', '2021-12-20 13:52:03'),
(4, 'rngspt@gmail.com', 'c3ec0f7b054e729c5a716c8125839829', 'Rangga Saputra', '2021-12-20 20:41:25'),
(6, 'c@gmail.com', 'c3ec0f7b054e729c5a716c8125839829', 'contoh', '2021-12-21 16:34:28'),
(7, 'rngs@gmail.com', 'c3ec0f7b054e729c5a716c8125839829', 'RNG Saputra', '2021-12-22 08:51:14'),
(8, 'hanum@gmail.com', 'c3ec0f7b054e729c5a716c8125839829', 'Hanum Maharani', '2021-12-22 10:32:53'),
(9, 'ranggasaputra@gmail.com', 'b2d70ecfea01ba7d1148f1dc5f593710', 'Rangga Saputra', '2021-12-31 10:12:02');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUsers` (`idUsers`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`idUsers`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
